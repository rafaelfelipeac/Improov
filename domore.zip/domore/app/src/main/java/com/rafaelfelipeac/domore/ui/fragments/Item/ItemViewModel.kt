package com.rafaelfelipeac.domore.ui.fragments.Item

import com.rafaelfelipeac.domore.ui.base.BaseViewModel

class ItemViewModel : BaseViewModel()