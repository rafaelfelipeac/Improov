package com.rafaelfelipeac.domore.ui.fragments.search

import com.rafaelfelipeac.domore.ui.base.BaseViewModel

class SearchViewModel : BaseViewModel() {
}