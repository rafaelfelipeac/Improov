package com.rafaelfelipeac.domore.ui.fragments.home

import com.rafaelfelipeac.domore.ui.base.BaseViewModel

class HomeViewModel() : BaseViewModel() 