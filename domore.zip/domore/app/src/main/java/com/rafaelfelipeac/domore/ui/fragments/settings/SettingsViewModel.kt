package com.rafaelfelipeac.domore.ui.fragments.settings

class SettingsViewModel {
}