package com.rafaelfelipeac.domore.ui.fragments.metrics

class MetricsViewModel {
}