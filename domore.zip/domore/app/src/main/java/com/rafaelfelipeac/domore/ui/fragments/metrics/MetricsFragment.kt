package com.rafaelfelipeac.domore.ui.fragments.metrics

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.rafaelfelipeac.domore.R
import com.rafaelfelipeac.domore.ui.activities.MainActivity
import kotlinx.android.synthetic.main.fragment_metrics.*
import com.hookedonplay.decoviewlib.charts.SeriesItem
import com.rafaelfelipeac.domore.ui.base.BaseFragment

class MetricsFragment : BaseFragment() {

//    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
//        (activity as MainActivity).supportActionBar?.title = "Metricas"
//
//        return inflater.inflate(R.layout.fragment_metrics, container, false)
//    }
//
//    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
//        super.onViewCreated(view, savedInstanceState)
//
//        arcView.addSeries(
//            SeriesItem.Builder(Color.argb(255, 218, 218, 218))
//                .setRange(0f, 100f, 100f)
//                .setInitialVisibility(false)
//                .setLineWidth(32f)
//                .build())
//
//        val seriesItem1 = SeriesItem.Builder(Color.argb(255, 64, 196, 0))
//            .setRange(0f, 100f, 0f)
//            .setLineWidth(32f)
//            .build()
//
//        arcView.addSeries(seriesItem1)
//    }
}
