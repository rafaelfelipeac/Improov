package com.rafaelfelipeac.domore.ui.fragments.goal

import com.rafaelfelipeac.domore.ui.base.BaseViewModel

class GoalViewModel: BaseViewModel() {
}